package XML;

public interface XMLObject {
	
	public String toXMLString();
	
}