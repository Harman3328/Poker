package GUI;

import Communications.Port;
import Poker.*;

/**
 * An abstract class defining a Poker UI.
 *
 * @author Kyle Robert Harrison
 */
public abstract class PokerClient {

    private Port<ClientEvent, GameEvent> port;
    protected GameState state;
    private Paytable paytable;
    
    /**
     * Create a client to play poker
     * @param port A port for communicating with the GameMaster
     */
    public PokerClient(Port<ClientEvent, GameEvent> port){
        this.port = port;
        paytable = Paytable.load("paytable.xml");
        System.out.println();
    }
    
    /**
     * Run the client.
     */
    public void run() {
        //implement me!
        state = new GameState(new PokerPlayer(),null,null,0);
        while (true) {
            port.send(new GameStartEvent(state));
            GameEvent gameEvent = port.recieve();
            gameEvent.execute(this);
            gameEvent.state.setSelected(getSelected(gameEvent.state.getPlayer().getHand()));
            port.send(new RequestRedrawEvent(gameEvent.state));
            gameEvent = port.recieve();
            gameEvent.execute(this);
            port.send(new RequestRankEvent(gameEvent.state));
            gameEvent = port.recieve();
            gameEvent.execute(this);
        }

    }

    public void setGameState(GameState state) {
        this.state = state;
    }
 
    public abstract int getBet(Player player);
    
    /**
     * Perform initialization actions.
     */
    public abstract void initialize();
    
    /**
     * Display the interface and present the initial hand.
     */
    public abstract void display(PokerHand hand);

    /**
     * Get the cards selected by the user for redraw.
     * @return Array indicating the cards to keep.
     */
    public abstract boolean[] getSelected(PokerHand hand);

    /**
     * Display the type of hand
     * @param handType The PokerRank object
     */
    public abstract void displayHandType(PokerRank handType);

    /**
     * Used to redisplay the hand after redraw.
     */
    public abstract void redisplay(PokerHand hand);

    
    public abstract void displayWinnings(int winnings);
    
    /**
     * Perform finalization actions.
     */
    public abstract void finalize();
    
    /**
     * Close the UI and exit the application.
     */
    public abstract void exit();
    
        /**
     * Determine the payout that a hand warrants
     * @param rank The rank of the hand
     * @param bet The amount of credits bet
     * @return The payout for this hand
     */
    public int determinePayout(PokerRank rank, int bet){
        int multiplier = paytable.getMultiplier(rank);
        return multiplier * bet;
    }
}
