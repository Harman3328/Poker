package GUI;

import Poker.GameState;

import java.io.Serializable;

/**
 * Sent by the GameMaster to signify a hand has been dealt
 * 
 * @author Kyle Robert Harrison
 */
public class DealEvent extends GameEvent implements Serializable {

    public DealEvent(GameState state) {
        super(state);
    }

    @Override
    public void execute(PokerClient client) {
        client.initialize();
        int bet = client.getBet(state.getPlayer());
        state.getPlayer().takeCredits(bet);
        state.setBet(bet);
        client.display(state.getPlayer().getHand());
    }
    
}
