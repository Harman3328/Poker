package GUI;

import Poker.GameState;

import java.io.Serializable;

/**
 * Sent by the GameMaster to signify the redraw has occurred.
 * @author Kyle Robert Harrison
 */
public class RedrawEvent extends GameEvent implements Serializable {

    public RedrawEvent(GameState state) {
        super(state);
    }

    @Override
    public void execute(PokerClient client) {
        client.redisplay(state.getPlayer().getHand());
    }
}
