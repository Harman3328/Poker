package GUI;

import Poker.GameState;

import java.io.Serializable;

/**
 *
 * Sent by the GameMaster to signify a hand has been ranked.
 * 
 * @author Kyle Robert Harrison
 */
public class RankEvent extends GameEvent implements Serializable {

    public RankEvent(GameState state) {
        super(state);
    }

    @Override
    public void execute(PokerClient client) {
        client.displayHandType(state.getRank());
        int winnings = client.determinePayout(state.getRank(), state.getBet());
        client.displayWinnings(winnings);
        state.getPlayer().addCredits(winnings);
        client.finalize();
    }
    
}
