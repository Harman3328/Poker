package GUI;


import Communications.Channel;
import Poker.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class client {

    public static void main(String[] args) {
        Socket socket = null;
        ObjectInputStream in = null;
        ObjectOutputStream out = null; 
        try {
            socket = new Socket("localhost", 40000);
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());

            Channel channel = new Channel();
            PokerClient pokerClient = new ConsoleClient(channel.asPort1());
            GameState gameState = new GameState(new PokerPlayer(), null, null, 0);
            pokerClient.setGameState(gameState);
            while (true) {
                out.writeObject(new GameStartEvent(pokerClient.state));
                out.flush();

                GameEvent gameEvent = (DealEvent) in.readObject();
                pokerClient.setGameState(gameEvent.state);
                gameEvent.execute(pokerClient);
                gameEvent.state.setSelected(pokerClient.getSelected(gameEvent.state.getPlayer().getHand()));
                out.writeObject(new RequestRedrawEvent(gameEvent.state));
                out.flush();

                gameEvent = (RedrawEvent) in.readObject();
                pokerClient.setGameState(gameEvent.state);
                gameEvent.execute(pokerClient);
                out.writeObject(new RequestRankEvent(gameEvent.state));
                out.flush();

                gameEvent = (RankEvent) in.readObject();
                pokerClient.setGameState(gameEvent.state);
                gameEvent.execute(pokerClient);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        try {
            socket.close();
            in.close();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
