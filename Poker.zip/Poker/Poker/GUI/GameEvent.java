package GUI;

import Poker.GameState;

import java.io.Serializable;


/**
 * An event which is produced by the GameMaster and executed by the PokerClient.
 * 
 * @author Kyle Robert Harrison
 */
public abstract class GameEvent implements Serializable {
    
    protected GameState state;
    
    public GameEvent(GameState state){
        this.state = state;
    }
    
    public abstract void execute(PokerClient client);
}
