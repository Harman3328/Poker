package GUI;

import Poker.*;
import Communications.Port;
import static Poker.PokerRank.*;
import java.util.Map.Entry;
import java.util.Scanner;

/**
 * Console-based implementation of PokerClient.  
 * This acts as the View in the MVC pattern.
 *
 * @author Kyle Robert Harrison
 */
public class ConsoleClient extends PokerClient implements Runnable {

    /**
     * Create a console-based client.
     * @param port A port for communicating with the GameMaster
     */
    public ConsoleClient(Port<ClientEvent, GameEvent>  port){
        super(port);
    }
    
    /**
     * {@inheritDoc}
     */
    public int getBet(Player player) {
        System.out.format("You have %d credits.%n", player.getCredits());
        Scanner scan = new Scanner(System.in);
        int credits = -1;
        boolean acceptable = false;
        do {
            System.out.print("Number of credits to bet: ");
            String s = scan.next();
            if(s.equalsIgnoreCase("exit")) exit();
            try{
                credits = Integer.parseInt(s);
            }
            catch(Exception e){
                System.out.format("%s is not an apprpriate number of credits.%n%n", s);
                acceptable = false;
                continue;
            }
            
            if(credits < 0){
                System.out.println("Number of credits cannot be negative");
                acceptable = false;
            }
            else if(credits > player.getCredits()){
                 System.out.println("Number of credits cannot exceed your credit balance.");
                 acceptable = false;
            }
            else{
                acceptable = true;
            }
            
        } while(!acceptable);
        
        System.out.format("Bet of %d received. You have %d credits remaining.%n%n", credits, player.getCredits() - credits);
        
        return credits;
    }
    

    /**
     * {@inheritDoc}
     */
    @Override
    public void display(PokerHand hand) {
        System.out.format("Initial Hand: %s %s %s %s %s%n%n", (Object[])hand.getCards());
    }

    /**
     * Get the cards selected by the user for redraw. Cards are selected by prompting the user (Y/N)
     * for each card in their hand.
     * @return Array indicating the cards to keep.
     */
    @Override
    public boolean[] getSelected(PokerHand hand) {
        boolean[] selected = new boolean[5];

        Scanner in = new Scanner(System.in);
        for(int i =0; i < hand.getCards().length; i++){
            try {
                char c;
                do {
                    System.out.format("Keep %s? (Y/N): ", hand.getCards()[i]);
                    c = in.next().charAt(0);
                    c = Character.toUpperCase(c);
                } while(c != 'Y' && c != 'N');

                selected[i] = c == 'Y';

            } catch (Exception e){System.err.println("Error while selecting cards to keep.");}
        }

        return selected;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void displayHandType(PokerRank handType) {
        System.out.format("Your hand is: %s%n%n", handType.getDescription());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void redisplay(PokerHand hand) {
        System.out.format("Final Hand: %s %s %s %s %s%n%n", (Object[])hand.getCards());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void exit(){
        System.exit(0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize() {
        System.out.println("New game starting!");
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public void finalize(){
        System.out.format("Game over. New game starting in 3 seconds.%n%n");
        try{ Thread.sleep(3000); }
        catch(Exception e) { }
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public void displayWinnings(int winnings) {
        if(winnings == 0){
            System.out.println("You didn't win. Better luck next time.");
        }
        else{
            System.out.format("Congratulations! You won %d credits!%n", winnings);
        }
        
        System.out.println();
    }
}
