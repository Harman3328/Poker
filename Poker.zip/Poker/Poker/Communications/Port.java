package Communications;

import java.io.Closeable;

/**
 * A Port is used for communication between two entities.
 * 
 * @param <S> The type of message to send 
 * @param <R>  The type of message to receive
 */
public interface Port<S, R> extends Closeable {

    /**
     * Send a message through the port
     * @param message The message to send
     */
    public void send(S message);

    /**
     * Receive a message through the port
     * @return The message received
     */
    public R recieve();

}
