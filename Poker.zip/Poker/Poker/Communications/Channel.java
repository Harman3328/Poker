package Communications;

import GUI.GameEvent;
import Poker.ClientEvent;

/**
 * A channel acts as a bidirectional queue to pass messages between
 * two ports.
 * 
 * @author Kyle Robert Harrison
 */
public class Channel {
	
    private Queue<GameEvent> port1ToPort2;
    private Queue<ClientEvent> port2ToPort1;

    public Channel() {
        port1ToPort2 = new Queue<>();
        port2ToPort1 = new Queue<>();
    }

    /**
     * Send a message to port 1
     * @param message
     */
    public void pushPort1(GameEvent message) {
        port1ToPort2.push(message);
    }

    /**
     * Send a message to port 2
     * @param message
     */
    public void pushPort2(ClientEvent message) {
        port2ToPort1.push(message);
    }

    /**
     * Receive a message from port 1
     * @return 
     */
    public ClientEvent pullPort1() {
        return port2ToPort1.pull();
    }

    /**
     * Receive a message from port 2
     * @return 
     */
    public GameEvent pullPort2() {
        return port1ToPort2.pull();
    }

    /**
     * Create Port 1
     * @return 
     */
    public Port asPort1() {
        return new Port<GameEvent, ClientEvent>() {
            public void send(GameEvent message) {
                pushPort1(message);
            }

            public ClientEvent recieve() {
                return pullPort1();
            }

            public void close() {
            }
        };
    }

    
    /**
     * Create Port 1
     * @return 
     */
    public Port asPort2() {
        return new Port<ClientEvent, GameEvent>() {
            public void send(ClientEvent message) {
                pushPort2(message);
            }

            public GameEvent recieve() {
                return pullPort2();
            }

            public void close() {
            }
        };
    }
}