package Main;


import Communications.Channel;
import GUI.ConsoleClient;
import GUI.PokerClient;

/**
 * The main entry point creates the GameMaster and the PokerClient.
 * It also establishes a Channel for communication between the GameMaster and PokerClient.
 *
 * @author Kyle Robert Harrison
 */
public class Main {

    public static void main(String[] args) throws InterruptedException {
        //Create Channel, GameMaster, and (in its own Thread) PokerClient
        Channel channel = new Channel();
        GameMaster gameMaster = new GameMaster(channel.asPort1());
        PokerClient client = new ConsoleClient(channel.asPort2());
        Thread thread = new Thread((Runnable) client);
        thread.start();
        Thread.sleep(1000);
        gameMaster.run();
    }
}
