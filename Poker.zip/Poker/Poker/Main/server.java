package Main;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class server {
    private static ArrayList<ServerConnections> threadPool = new ArrayList<>();

    /**
     * Creates a 100 new instances of ServerConnections which will be distributed to clients
     * @param size size of the thread pool
     */
    private static void createThreadPool(int size) {
        for (int i = 0; i < size; i++) {
            threadPool.add(new ServerConnections());
        }
    }

    /**
     * goes through the thread pool to check available instance
     * If there are no instances available, adds more instances to the thread pool
     * @return an instance of ServerConnections
     */
    private static ServerConnections getAvailableInstance() {
        for (int i = 0; i < threadPool.size(); i++) {
            ServerConnections connections = threadPool.get(i);
            if (connections.getAvailable()) {
                connections.setAvailable(false);
                return connections;
            }
        }
        int previousSize = threadPool.size();
        createThreadPool(10);
        return threadPool.get(previousSize);
    }

    /**
     * creates a ServerSocket, then waits for a client to connect before giving it an instance of ServerConnections
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        createThreadPool(100);
        ServerSocket serverSocket = new ServerSocket(40000);
        while (true) {
            Socket socket = null;
            try {
                socket = serverSocket.accept();

                System.out.println("A new client is connected: " + socket);

                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());


                ServerConnections connections = getAvailableInstance();
                connections.setIn(in);
                connections.setOut(out);
                connections.setSocket(socket);

                connections.start();
            } catch (IOException e) {
                socket.close();
                serverSocket.close();
                break;
            }
        }
        serverSocket.close();
    }
}
