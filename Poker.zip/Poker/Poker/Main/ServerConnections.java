package Main;

import GUI.DealEvent;
import GUI.RankEvent;
import GUI.RedrawEvent;
import Poker.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServerConnections extends Thread{
    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    private Dealer dealer;
    private HandRanker handRanker;
    boolean openSocket = true;
    private boolean available = true;

    public ServerConnections() {
        super ("ServerConnectionThread");
    }

    /**
     * sets the socket
     * @param socket connecting socket
     */
    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    /**
     * sets ObjectInputStream
     * @param in connecting socket's ObjectInputStream
     */
    public void setIn(ObjectInputStream in) {
        this.in = in;
    }

    /**
     * sets ObjectOutputStream
     * @param out connecting socket's ObjectOutputStream
     */
    public void setOut(ObjectOutputStream out) {
        this.out = out;
    }

    /**
     * sets false if a client is using this instance else true
     * @param available
     */
    public void setAvailable(boolean available) {
        this.available = available;
    }

    /**
     *
     * @return true if instance isn't being used by a client else false
     */
    public boolean getAvailable() {
        return available;
    }

    /**
     * Communication between the client
     * @throws IOException
     */
    private void sendTOClient() throws IOException {
        try {
            ClientEvent clientEvent = (GameStartEvent) in.readObject();
            clientEvent.execute(dealer, handRanker);
            out.writeObject(new DealEvent(clientEvent.getState()));
            out.flush();

            clientEvent = (RequestRedrawEvent) in.readObject();
            clientEvent.execute(dealer, handRanker);
            out.writeObject(new RedrawEvent(clientEvent.getState()));
            out.flush();

            clientEvent = (RequestRankEvent) in.readObject();
            clientEvent.execute(dealer, handRanker);
            out.writeObject(new RankEvent(clientEvent.getState()));
            out.flush();
        } catch (IOException | ClassNotFoundException e) {
            openSocket = false;
            System.out.println(socket + " disconnected");
            available = true;
        }
    }

    public void run() {
        dealer = new Dealer();
        handRanker = new HandRanker();

        while (openSocket) {
            try {
                if (dealer.getDeckSize() < 5) dealer = new Dealer();
                sendTOClient();
            } catch (IOException e) {
                try {
                    in.close();
                    out.close();
                    socket.close();
                    openSocket = false;
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                e.printStackTrace();
                available = true;
                openSocket = false;
            }
        }
    }
}
