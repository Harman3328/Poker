package Main;

import GUI.GameEvent;
import GUI.RedrawEvent;
import GUI.RankEvent;
import Poker.ClientEvent;
import GUI.DealEvent;
import Communications.Port;
import Poker.*;

/**
 * The GameMaster is responsible for controlling the execution of the game.
 * This acts as the Controller in the MVC pattern.
 *
 * @author Kyle Robert Harrison
 */
class GameMaster {
    
    private Dealer dealer;
    private HandRanker ranker;
    Port<GameEvent, ClientEvent> port;

    public GameMaster(Port<GameEvent, ClientEvent> port){
        dealer = new Dealer();
        ranker = new HandRanker();
        this.port = port;
    }

    /**
     * Execute the game.
     */
    public void run(){
        //implement me!
        while (true) {
            ClientEvent clientEvent = port.recieve();
            clientEvent.execute(dealer, ranker);
            port.send(new DealEvent(clientEvent.getState()));
            clientEvent = port.recieve();
            clientEvent.execute(dealer, ranker);
            port.send(new RedrawEvent(clientEvent.getState()));
            clientEvent = port.recieve();
            clientEvent.execute(dealer, ranker);
            port.send(new RankEvent(clientEvent.getState()));
        }
    }

}
