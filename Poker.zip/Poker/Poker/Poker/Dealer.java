package Poker;

import Cards.*;

/**
 * The dealer is responsible for handling the distribution of cards.
 *
 * @author Kyle Robert Harrison
 */
public class Dealer {

    private Deck deck;

    public Dealer(){
        this.deck = new StandardDeck();
        deck.shuffle();
    }

    /**
     * Deal a hand of 5 cards.
     * @return the PokerHand containing the 5 dealt cards.
     * @throws OutOfCardsException
     */
    public PokerHand dealHand() throws OutOfCardsException{
        return deal(5);
    }

    
    public PokerHand deal(int cards) throws OutOfCardsException {
        return new PokerHand(deck.next(cards));
    }
    
    /**
     * "Burn" the top card of the deck, i.e., discard the top card.
     */
    public void burnCard() throws OutOfCardsException{
        deck.next();
    }

    /**
     * Perform the redraw phase given a hand and an indication of the cards to redraw.
     * @param hand The hand which is being redrawn.
     * @param selected An array indicating which cards are to be kept. Entries which are false will be replaced.
     * @throws OutOfCardsException
     */
    public void redraw(PokerHand hand, boolean[] selected) throws OutOfCardsException{

        if(selected.length != 5) throw new IllegalArgumentException("Selected array must be of length 5");

        for (int j = 0; j < 5; j++) {
            if (!selected[j]) hand.replaceCard(j, deck.next());
        }
    }

    public int getDeckSize() {
        return deck.deckSize();
    }

}
