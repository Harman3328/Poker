package Poker;

import Poker.*;

import java.io.Serializable;

/**
 * Sent by the PokerClient to signify the start of a game.
 * 
 * @author Kyle Robert Harrison
 */
public class GameStartEvent extends ClientEvent implements Serializable {

    public GameStartEvent(GameState state){
        super(state);
    }
    
    @Override
    public void execute(Dealer dealer, HandRanker ranker) {
        try{
            state.getPlayer().receiveHand(dealer.dealHand());
        }
        catch(Exception e) {  }
       
    }
    
}
