package Poker;

/**
 * Sent by the PokerClient to signify a request for redraw.
 * 
 * @author Kyle Robert Harrison
 */
public class RequestRedrawEvent extends ClientEvent {

    public RequestRedrawEvent(GameState state){
        super(state);
    }
    
    @Override
    public void execute(Dealer dealer, HandRanker ranker) {
        
        try{
            dealer.redraw(state.getPlayer().getHand(), state.getSelected());
        }
        catch(Exception e) { }
    }
    
}
