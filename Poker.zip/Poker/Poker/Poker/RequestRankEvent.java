package Poker;

import java.io.Serializable;

/**
 * Sent by the PokerClient to signify a request to rank the hand.
 * 
 * @author Kyle Robert Harrison
 */
public class RequestRankEvent extends ClientEvent implements Serializable {

    public RequestRankEvent(GameState state){
        super(state);
    }
    
    @Override
    public void execute(Dealer dealer, HandRanker ranker) {
        state.setRank(ranker.evaluateHand(state.getPlayer().getHand()));
    }
    
}
