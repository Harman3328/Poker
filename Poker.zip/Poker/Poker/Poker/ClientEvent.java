package Poker;

import java.io.Serializable;

/**
 * An event which is produced by the PokerClient and executed by the GameMaster.
 * 
 * @author Kyle Robert Harrison
 */
public abstract class ClientEvent implements Serializable {
    
    protected GameState state;
    
    public ClientEvent(GameState state){
        this.state = state;
    }
    
    /**
     * Return the current game state.
     * @return 
     */
    public GameState getState(){
        return state;
    }
    
    /**
     * Execute this action using a specified dealer and ranker.
     * 
     * @param dealer The dealer 
     * @param ranker The ranker
     */
    public abstract void execute(Dealer dealer, HandRanker ranker);
}
