package Poker;

import java.util.*;

/**
 * Handles the ranking of hands and facilitates the comparison of two PokerHand objects
 * by implementing a Comparator of type PokerHand
 *
 * @author Kyle Robert Harrison
 */
public class HandRanker implements Comparator<PokerHand>{

    private Paytable paytable;
    
    public HandRanker(){
        paytable = Paytable.load("paytable.xml");
    }
    
    /**
     * Employ the use of the CardAdapter to rank the given hand.
     * @param hand The hand to be ranked.
     * @return The type of hand.
     */
    public PokerRank evaluateHand(PokerHand hand){
        PokerCard[] cards = new PokerCard[hand.getCards().length];

        for(int i = 0; i < cards.length; i++){
            cards[i] = new CardAdapter(hand.getCards()[i]);
        }

        return new PokerRank(cards);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int compare(PokerHand hand1, PokerHand hand2) {
        PokerRank r1 = evaluateHand(hand1);
        PokerRank r2 = evaluateHand(hand2);

        return Integer.compare(r1.getRank(), r2.getRank());
    }
    

}
