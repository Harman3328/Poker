
package Poker;

import XML.XMLNodeConverter;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Kyle Robert Harrison
 */
public class PayoutReader implements XMLNodeConverter<Payout> {

    @Override
    public Payout convertXMLNode(Node node) {
        String text = node.getTextContent();
        char[] array = text.toCharArray();
        int rank = Integer.parseInt(String.valueOf(array[0]));
        int pay = Integer.parseInt(String.valueOf(array[1]));
        return new Payout(rank, pay);
    }

}
