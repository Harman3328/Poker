package Poker;

import java.io.Serializable;

/**
 * Basic implementation of the Player interface.
 * This represents a human player in the game.
 *
 * @author Kyle Robert Harrison
 */
public class PokerPlayer implements Player, Serializable {

    private PokerHand hand;
    private int credits;

    public PokerPlayer() {
        this(100); 
    }
    
    public PokerPlayer(int credits){
        this.credits = credits;
    }

    @Override
    public int getCredits(){
        return credits;
    }
    
    @Override
    public void takeCredits(int credits){
        this.credits -= credits;
    }
    
    @Override
    public void addCredits(int credits){
        this.credits += credits;
    }
    

    /**
     * {@inheritDoc}
     */
    @Override
    public void receiveHand(PokerHand hand) {
        this.hand = hand;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public PokerHand getHand() {
        return hand;
    }
}
