
package Poker;

import XML.XMLReader;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 *
 * @author Kyle Robert Harrison
 */
public class Paytable {
    Map<Integer, Integer> payouts;
    
    //the rank value of a pair of jacks
    static final int PAIR_OF_JACKS = 1814528;
    
    public Paytable(){
        payouts = new HashMap<>();
    }
    
    public void addPayout(Payout payout){
        addPayout(payout.rank, payout.payout);
    }
    
    public void addPayout(Integer rank, Integer payout){
        payouts.put(rank, payout);
    }
    
    public static Paytable load(String filename){
        XMLReader<Paytable> reader = new XMLReader<>();
        reader.setXMLSchema("paytable.xsd");
        reader.setXMLNodeConverter(new PaytableReader());
        return reader.readXML(filename);
    }
    
    public int getMultiplier(PokerRank rank){
        int type = rank.getHandType();
        
        //if hand type is pair, must ensure it is better than a pair of jacks
        //pair of jacks is rank 1814528
        if(type == PokerRank.PAIR && rank.getRank() < PAIR_OF_JACKS){ 
            return 0;
        }
        return payouts.get(type);
    }
    
    public Set<Entry<Integer,Integer>> getEntries(){
        return payouts.entrySet();
    }
}
