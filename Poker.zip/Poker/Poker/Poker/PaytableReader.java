
package Poker;

import XML.XMLNodeConverter;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Kyle Robert Harrison
 */
public class PaytableReader implements XMLNodeConverter<Paytable> {

    private PayoutReader payoutReader;
    
    public PaytableReader(){
        payoutReader = new PayoutReader();
    }
    
    @Override
    public Paytable convertXMLNode(Node node) {
        Paytable paytable = new Paytable();
        payoutReader = new PayoutReader();
        NodeList nodeList = node.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node childNode = nodeList.item(i);
            if (childNode.getNodeType() == Node.ELEMENT_NODE) {
                paytable.addPayout(payoutReader.convertXMLNode(childNode));
            }
        }
        return paytable;
    }
    
}
