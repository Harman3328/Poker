
package Poker;

/**
 *
 * @author Kyle Robert Harrison
 */
class Payout {
    int rank;
    int payout;
    
    public Payout(int rank, int payout){
        this.rank = rank;
        this.payout = payout;
    }
}
