package Poker;

import Cards.Card;

import java.io.Serializable;

/**
 * Class adapter to adapt Card to PokerCard such that it can be used by PokerRank.
 *
 * @author Kyle Robert Harrison
 */
class CardAdapter extends PokerCard implements Serializable {

    public CardAdapter(Card c){
        super(c.getRank().getRankValue(), c.getSuit().getSuitValue());
    }
}
