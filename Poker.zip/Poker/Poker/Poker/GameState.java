package Poker;

import java.io.Serializable;

/**
 *
 * Represents the state of the game and is used as the primary information 
 * to be passed between the PokerClient and the GameMaster.
 * 
 * The GameState contains three pieces of information:
 * 
 * 1. The player
 * 2. An array of booleans indicating which cards have been selected to keep.
 * 3. A PokerRank object.
 * 
 * @author Kyle Robert Harrison
 */
public class GameState implements Serializable {
    
    private Player player;
    private boolean[] selected;
    private PokerRank rank;
    private int bet;

    public GameState(Player player, boolean[] selected, PokerRank rank, int bet){
        this.player = player;
        this.selected = selected;
        this.rank = rank;
        this.bet = bet;
    }
    
    public void setPlayer(Player player){
        this.player = player;
    }
    
    public Player getPlayer(){
        return player;
    }
    
    public void setSelected(boolean[] selected){
        this.selected = selected;
    }
    
    public boolean[] getSelected(){
        return selected;
    }
    
    public void setRank(PokerRank rank){
        this.rank = rank;
    }
    
    public PokerRank getRank(){
        return rank;
    }
    
    public void setBet(int bet){
        this.bet = bet;
    }
    
    public int getBet(){
        return bet;
    }
    
    
}
