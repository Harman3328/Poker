package Poker;


/**
 * Very minimal interface defining a player in the poker game.
 *
 * @author Kyle Robert Harrison
 */
public interface Player {

    /**
     * Get the number of credits this player has
     * @return The number of credits
     */
    int getCredits();
    
    /**
     * Take a number of credits from a player's balance
     * @param credits The number of credits to take
     */
    void takeCredits(int credits);
    
    /**
     * Add credits to a player's balance
     * @param credits The number of credits to add
     */
    void addCredits(int credits);
    
    
    /**
     * Receive an initial hand.
     * @param hand
     */
    void receiveHand(PokerHand hand);

    /**
     * Return the hand this player currently has.
     * @return
     */
    PokerHand getHand();
}
