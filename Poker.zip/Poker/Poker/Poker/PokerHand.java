package Poker;

import Cards.Card;

import java.io.Serializable;

/**
 * Implementation of a hand of cards.
 *
 * @author Kyle Robert Harrison
 */
public class PokerHand implements Serializable {

    private Card[] cards;

    /**
     * Constuct a hand given an array of cards.
     * @param cards The cards this hand will contain.
     */
    public PokerHand(Card[] cards){
        this.cards = cards;
    }

    /**
     * Return the cards contained in this hand.
     * @return An array of cards in this hand.
     */
    public Card[] getCards() {
        return cards;
    }

    /**
     * Replace the Card at the given index with a new Card.
     * @param index The index of the card to replace.
     * @param card The new Card.
     * @return true if the card was replaced (i.e., the index was valid). False otherwise.
     */
    public boolean replaceCard(int index, Card card){
        if(index < 0 || index > cards.length - 1) return false;
        else cards[index] = card;

        return true;
    }
}
