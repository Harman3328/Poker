package Cards;

/**
 * An exception to be thrown if there are no cards remaining in the deck.
 *
 * @author Kyle Robert Harrison
 */
public class OutOfCardsException extends Exception {

    public OutOfCardsException(){
        super("Insufficient cards available.");
    }
}
