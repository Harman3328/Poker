package Cards;

import java.io.Serializable;

/**
 * This class represents a standard playing card.
 *
 * @author Kyle Robert Harrison
 */
public class Card implements Serializable {

    private final Suit suit;
    private final Rank rank;

    /**
     * Construct a card with the given rank and suit.
     * @param rank The rank of the card
     * @param suit The suit of the card
     */
    public Card(Rank rank, Suit suit){
        this.rank = rank;
        this.suit = suit;
    }

    /**
     * Return the suit of the card.
     * @return
     */
    public Suit getSuit() {
        return suit;
    }

    /**
     * Return the rank (i.e., value) of a card
     * @return
     */
    public Rank getRank() {
        return rank;
    }

    /**
     * Cards are equal if they share the same suit and rank
     * @param obj the other card to compare
     * @return true if the cards share the same suit and rank. False otherwise
     */
    @Override
    public boolean equals(Object obj){
        if(obj == null || !(obj instanceof Card)) return false;
        else {
            Card other = (Card) obj;

            return rank == other.rank && suit == other.suit;
        }
    }

    /**
     * The string representation of the card. The representation is the rank and the ASCII character
     * corresponding to the suit.
     * @return A string representation of a card.
     */
    @Override
    public String toString(){
        return this.getRank() + " " + this.getSuit().getASCIICharacter();
    }
}
