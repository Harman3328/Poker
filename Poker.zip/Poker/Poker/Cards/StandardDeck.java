package Cards;

import java.util.*;

/**
 * Implementation of a standard 52-card deck of playing cards
 *
 * @author Kyle Robert Harrison
 */
public class StandardDeck implements Deck{
    private List<Card> cards;

    public StandardDeck(){
        cards = new ArrayList<>(52);

        initialize();
    }

    /**
     * {@inheritDoc}
     */
    public void initialize(){

        cards.clear();

        for(Suit suit : Suit.values()){
            for(Rank rank : Rank.values()){
                cards.add(new Card(rank, suit));
            }
        }

    }

    /**
     * Shuffle the deck by calling Collections.shuffle
     */
    public void shuffle(){
        Collections.shuffle(cards);
    }

    /**
     * {@inheritDoc}
     */
    public Card next() throws OutOfCardsException {
        if(cards.size() == 0) throw new OutOfCardsException();
        return cards.remove(0); //remove last element to prevent copying
    }

    /**
     * {@inheritDoc}
     */
    public Card[] next(int n) throws OutOfCardsException{
        if(cards.size() < n) throw new OutOfCardsException();
        Card[] result = new Card[n];

        for(int i = 0; i < n; i++){
            result[i] = next();
        }

        return result;
    }

    @Override
    public int deckSize() {
        return cards.size();
    }
}
