package Cards;

/**
 * An interface defining a deck of Cards
 *
 * A deck must provide these behaviours:
 * 1. Provide the next card
 * 2. Provide the next n cards.
 * 3. Reset to an initial state
 * 4. Shuffle the contained cards
 *
 * @author Kyle Robert Harrison
 */
public interface Deck {

    /**
     * Reset the deck to its initial state
     */
    void initialize();

    /**
     * Shuffle the deck
     */
    void shuffle();

    /**
     * Get the next card in the deck.
     * @return The next Card in the deck
     * @throws OutOfCardsException
     */
    Card next() throws OutOfCardsException;

    /**
     * Get the next n cards from the deck.
     * @param n The number of cards to retrieve
     * @return An array containing n cards.
     * @throws OutOfCardsException
     */
    Card[] next(int n) throws OutOfCardsException;

    int deckSize();
}
