package Cards;

/**
 * Enumeration defining the suit of a playing card.
 *
 * @author Kyle Robert Harrison
 */
public enum Suit{
    CLUBS(3),
    DIAMONDS(2),
    HEARTS(1),
    SPADES(0);

    private final int value;

    Suit(int value){
        this.value = value;
    }

    public int getSuitValue(){
        return value;
    }

    /**
     * Return the Unicode ASCII character associated with this card.
     * @return
     */
    public char getASCIICharacter(){
        switch (this){
            case CLUBS:
                return '\u2663';
            case DIAMONDS:
                return '\u2666';
            case HEARTS:
                return '\u2665';
            case SPADES:
                return '\u2660';
        }

        return ' ';
    }

}
